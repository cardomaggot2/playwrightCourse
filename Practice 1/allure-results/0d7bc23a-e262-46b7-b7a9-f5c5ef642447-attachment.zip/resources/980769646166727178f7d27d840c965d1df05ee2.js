(function () {
  // font families
  var families = [
    "nissan-ag",
    "nissan-pro-condensed",
    "nissan-prox-bold-condensed",
    "Nissan Light",
    "Nissan Bold",
    "Nissan Regular",
  ];

  // family css file urls
  var fontCSSURLs = [
    "https://www.nissanusa.com/content/dam/Nissan/us/assets/includes/new-menu/common-assets/fonts/nissan-ag.css",
    "https://www.nissanusa.com/content/dam/Nissan/us/assets/includes/new-menu/common-assets/fonts/nissan-pro-condensed.css",
    "https://www.nissanusa.com/content/dam/Nissan/us/assets/includes/new-menu/common-assets/fonts/nissan-prox-bold-condensed.css",
    "https://www.nissanusa.com/content/dam/Nissan/us/assets/includes/new-menu/common-assets/fonts/Nissan-BrandW01-Bold.css",
    "https://www.nissanusa.com/content/dam/Nissan/us/assets/includes/new-menu/common-assets/fonts/Nissan-BrandW01-Light.css",
    "https://www.nissanusa.com/content/dam/Nissan/us/assets/includes/new-menu/common-assets/fonts/Nissan-BrandW01-Regular.css",
  ];

  WebFontConfig = {
    custom: {
      families: families,
      urls: fontCSSURLs,
    },
  };

  // nav panel fix
  document.addEventListener("nissanNavLoaded", function () {
    var navFlyout = document
      .getElementById("nissan_global_header")
      .getElementsByClassName("c_320B")[0]
      .getElementsByClassName("c_320B-flyout")[0];
    navFlyout.style.display = "unset";
  });

  document.addEventListener("DOMContentLoaded", function () {
    var bodyElement = document.body;
    var url = window.location.href;

    if (url.indexOf("es.nissanusa.com/shopping-tools") > -1) {
      bodyElement.classList.add("linkout-nav-full-width");
    }
  });

  // under-30K Campaign

  document.addEventListener("DOMContentLoaded", function () {
    var checkInterval;
    var originalStates = [];
    if (window.location.href.indexOf("under-30k") !== -1) {
      window.location.href = "/shopping-tools/build-price?budget=30000";
    }
    // Function to check if the anchor element loads
    function revertChanges() {
      var promoElements = document.querySelectorAll(
        ".PromoFiltersstyles__PromoWrap-sc-1mo3o3x-2"
      );
      Array.prototype.forEach.call(promoElements, function (element, index) {
        var originalState = originalStates[index];
        if (originalState) {
          // Revert href
          element.setAttribute("href", originalState.href);

          // Revert pointer-events
          element.style.pointerEvents = originalState.pointerEvents;

          // Revert image opacity
          var img = element.querySelector("img");
          if (img && originalState.imgOpacity !== null) {
            img.style.opacity = originalState.imgOpacity;
          }

          // Revert paragraph colors
          var paragraphs = element.querySelectorAll("p");
          Array.prototype.forEach.call(paragraphs, function (p, pIndex) {
            p.style.color = originalState.paragraphColors[pIndex];
          });
        }
      });
    }

    function modifyElements() {
      var promoElements = document.querySelectorAll(
        ".PromoFiltersstyles__PromoWrap-sc-1mo3o3x-2"
      );
      Array.prototype.forEach.call(promoElements, function (element, index) {
        if (element.hasAttribute("href")) {
          var hrefValue = element.getAttribute("href");
          if (
            hrefValue.indexOf("/shopping-tools/build-price?promo=under-30k") !==
            -1
          ) {
            // Store the original state
            var img = element.querySelector("img");
            var paragraphs = element.querySelectorAll("p");
            originalStates[index] = {
              href: hrefValue,
              pointerEvents: element.style.pointerEvents,
              imgOpacity: img ? img.style.opacity : null,
              paragraphColors: Array.prototype.map.call(
                paragraphs,
                function (p) {
                  return p.style.color;
                }
              ),
            };

            // Modify the element
            element.setAttribute(
              "href",
              "/shopping-tools/build-price?promo=under-30k"
            );
            element.setAttribute("aria-current", "page");
            element.style.pointerEvents = "none";
            if (img) {
              img.style.opacity = "0.4";
            }
            Array.prototype.forEach.call(paragraphs, function (p) {
              p.style.color = "black";
            });
          }
        }
      });
    }
    function checkAnchorElement() {
      // Select the anchor element with the specific href attribute
      var currentURL = window.location.href;
      var promoLink = document.querySelector(
        'a[href="/shopping-tools/build-price?promo=under-30k"]'
      );

      // Check if the element exists
      if (
        promoLink &&
        currentURL.indexOf("shopping-tools/build-price?budget=30000") == -1
      ) {
        // Update the href attribute
        promoLink.setAttribute(
          "href",
          "/shopping-tools/build-price?budget=30000"
        );
        promoLink.addEventListener("click", function (event) {
          event.preventDefault();
          event.stopPropagation();
          window.location.href = "/shopping-tools/build-price?budget=30000";
        });

        revertChanges();
        clearInterval(checkInterval); // Stop checking once found and updated
      } else if (
        currentURL.indexOf("shopping-tools/build-price?budget=30000") !== -1
      ) {
        modifyElements();
        clearInterval(checkInterval); //
      }
    }

    // Function to continuously check the URL

    // Call the function to check the URL repeatedly with a time interval of 1 second (1000 milliseconds)
    function restartCheckInterval() {
      checkInterval = setInterval(checkAnchorElement, 1000); // Restart checkInterval
    }
    document.addEventListener("click", restartCheckInterval);
  });
})();
