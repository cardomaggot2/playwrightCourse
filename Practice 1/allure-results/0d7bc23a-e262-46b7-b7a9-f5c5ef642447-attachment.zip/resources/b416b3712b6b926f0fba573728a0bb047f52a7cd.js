(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6816],{19284:function(e,t,i){var n={"./360.svg":37486,"./arrow.svg":51115,"./asterisk.svg":48599,"./back-caret-infiniti.svg":11501,"./back-caret-nissan.svg":44395,"./brake-fluid-change.svg":2655,"./calculator-infiniti.svg":936,"./calculator-nissan.svg":54154,"./calculator.svg":59453,"./car-rental.svg":20499,"./caret-2.svg":45156,"./caret-infiniti.svg":30846,"./caret-l-infiniti.svg":61581,"./caret-l-nissan.svg":75041,"./caret-m-infiniti.svg":39780,"./caret-m-nissan.svg":12611,"./caret-nissan.svg":62951,"./caret-xl.svg":12473,"./check-infiniti.svg":76362,"./check-nissan.svg":96265,"./circle-arrow.svg":61003,"./circle-check-light-fill.svg":40852,"./circle-check-light.svg":73432,"./circle-check.svg":17917,"./collapse-infiniti.svg":90451,"./collapse-nissan.svg":77702,"./down-caret-infiniti.svg":82570,"./down-caret-nissan.svg":53858,"./electric-vehicle.svg":63576,"./error-infiniti.svg":78729,"./error-nissan.svg":41094,"./expand-infiniti.svg":37914,"./expand-nissan.svg":13665,"./external-link.svg":98857,"./facebook-infiniti.svg":19468,"./facebook-nissan.svg":63172,"./favorite-2.svg":99862,"./favorite-infiniti 2.svg":85407,"./favorite-infiniti.svg":42606,"./favorite-nissan.svg":22743,"./filters-light.svg":27536,"./filters.svg":19499,"./geolocator-infiniti.svg":59024,"./geolocator-nissan.svg":42458,"./homedealer-grey.svg":82212,"./homedealer-transparent.svg":47213,"./homedealer-white.svg":73889,"./hotspot-selected.svg":51905,"./hotspot-unselected.svg":78755,"./info-invert.svg":41422,"./info.svg":59361,"./inspection.svg":62197,"./link-2.svg":3344,"./link.svg":5458,"./locate-pin-2.svg":35258,"./locate-pin-3-empty.svg":95133,"./locate-pin.svg":71732,"./locate.svg":70264,"./location-pin-infiniti.svg":34541,"./location-pin-nissan.svg":62329,"./maximize-light.svg":52239,"./maximize.svg":97448,"./menu.svg":23818,"./messenger.svg":82592,"./minimize.svg":87715,"./minus-2.svg":63355,"./minus-infiniti.svg":59310,"./minus-nissan.svg":30446,"./oil-change.svg":34305,"./plus-2.svg":35649,"./plus-infiniti.svg":43492,"./plus-m.svg":34179,"./plus-nissan.svg":78502,"./pricing-offers-circle-infiniti.svg":60400,"./pricing-offers-circle-nissan.svg":92116,"./pricing-offers-infiniti.svg":99176,"./pricing-offers-nissan.svg":99483,"./quote-infiniti.svg":41492,"./quote-nissan.svg":21498,"./refresh-light.svg":68155,"./refresh.svg":38825,"./replace.svg":34090,"./reset-infiniti.svg":29060,"./reset-nissan.svg":37893,"./road-hazard.svg":88721,"./save.svg":68097,"./search-inventory-infiniti.svg":62358,"./search-inventory-nissan 2.svg":78735,"./search-inventory-nissan.svg":33341,"./search-inventory.svg":19963,"./search-light.svg":45185,"./search.svg":42907,"./service.svg":60086,"./share.svg":99593,"./sort-by-light.svg":54662,"./sort-by.svg":44171,"./switch-2.svg":48909,"./switch-infiniti.svg":16857,"./switch-nissan.svg":26364,"./three-dots.svg":40368,"./time.svg":76031,"./trade-in-quote-2.svg":72007,"./trade-in-quote-infiniti.svg":5037,"./trade-in-quote-nissan.svg":28038,"./trade-in-quote.svg":57515,"./twitter-infiniti.svg":56650,"./twitter-nissan.svg":32182,"./up-caret-infiniti.svg":38503,"./up-caret-nissan.svg":34600,"./vehicle-infiniti.svg":11319,"./vehicle-nissan.svg":54918,"./vehicle-preowned-infiniti.svg":52372,"./vehicle-preowned-nissan.svg":86057,"./view-filter-infiniti.svg":98430,"./view-filter-nissan.svg":71817,"./view-grid-infiniti.svg":63843,"./view-grid-nissan.svg":90514,"./view-list-infiniti.svg":51780,"./view-list-nissan.svg":2113,"./wallet.svg":22636,"./wheel-default.svg":25285,"./wheel-infiniti.svg":95786,"./wheel-nissan.svg":54428,"./x-l.svg":87485,"./x-m.svg":48831,"./x.svg":11437};function r(e){return i(s(e))}function s(e){if(!i.o(n,e)){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}return n[e]}r.keys=function(){return Object.keys(n)},r.resolve=s,e.exports=r,r.id=19284},9557:function(){},74400:function(e,t,i){Promise.resolve().then(i.bind(i,18667))},33604:function(e,t,i){"use strict";i.d(t,{u:function(){return r}});var n=i(82847);let r=async(e,t=1)=>new Promise((i,r)=>{if(n.Z){let n=document.createElement("script");n.onload=()=>{i()},n.onerror=()=>{r()},n.defer=t,n.src=e,document.body.appendChild(n)}else i()})},54672:function(e,t,i){"use strict";i.d(t,{f:function(){return d}});var n=i(2265),r=i(40718),s=i.n(r),a=i(36970),o=i(54022),l=i(33604),c=i(89618);let f={nissan:{ca:{default:"63px",medium:"121px",large:"121px"},us:{default:"82px",medium:"82px",large:"146px"}},infiniti:{ca:{default:"67px",medium:"120px",large:"120px"},us:{default:"63px",medium:"120px",large:"120px"}}},g=(e,t)=>{let i=e.isNissan?"nissan":"infiniti",n=e.isCanada?"ca":"us";return f[i][n][t]},d=e=>({theme:t})=>g(t,e),m=c.ZP.div`
  width: 100%;
  height: ${d("default")};
  @media only screen and (min-width: 48em) {
    height: ${d("medium")};
  }
  @media only screen and (min-width: 60em) {
    height: ${d("large")};
  }
`,u=c.ZP.div`
  top: 0;
  position: ${({$isFixed:e,$forcePositionAbsolute:t})=>t?"absolute":e?"fixed":"static"};
  width: 100%;
  z-index: 1;
  transition: transform 0.3s ${({theme:e})=>e.easing.easeInQuad};
  ${({theme:e})=>e.isCanada&&e.isInfiniti&&`
    background: ${e.color.primaryWhite};
    max-width: 100% !important;
    border-bottom: none !important;

    & #brand-banner {
      border-bottom: 1px solid #EEEEEE;
    }
  `}

  .helios .c_010 {
    /* infiniti global nav has z-index of 600. reset to 1 */
    z-index: 1;
  }
  .helios .c_010 .logo {
    transition: transform 0.3s ${({theme:e})=>e.easing.easeInQuad},
      opacity 0.2s ${({theme:e})=>e.easing.easeOutExpo};
  }

  .helios .c_010 .search-form {
    width: 100% !important;
    left: 0;
  }

  .helios .c_010 .search-bar-container .nav-site-search {
    width: 100% !important;
    left: 0;
  }

  .helios .c_010 .search-bar-container .nav-site-search .search-entry {
    width: 100% !important;
  }

  ${({$visible:e,theme:t})=>!e&&`
    transform: translateY(-${g(t,"large")});
    .helios .c_010 .logo {
      opacity: 0;
      transform: translateY(-75px);
    }
  `}

  ${({$visible:e,$shouldCollapseOffStage:t})=>!e&&t&&`
    transform: translateY(-160px);
    `};
`,p=null,h=0,v=e=>document.getElementById(`${e}_global_header`),x=()=>{p&&(p.remove(),p=null)},b=async(e,t,i,n,r)=>{let s=v(e);(null===s||!s.children.length)&&(await (0,l.u)(t),r||(await (0,l.u)(i),await (0,l.u)(n)))},y=({navScript:e=null,linkOutScript:t=null,menuLib:i=null,pageIncludesGlobalFooter:r,visible:s=!0,isFixed:l=!1,forcePositionAbsolute:c=!1,shouldCollapseOffStage:f=!1,shouldCollapseOnScroll:g=!1,brandOverride:d=null})=>{let{brand:y}=(0,a.Z)();null!==d&&(y=d);let[w,T]=(0,n.useState)(!0);return(0,n.useEffect)(()=>{b(y,e,t,i,r)},[]),(0,n.useEffect)(()=>{let e=v(y);e&&Array.from(e.querySelectorAll("button, a")).forEach(e=>{e.tabIndex=s?0:-1})},[y,s]),(0,n.useEffect)(()=>{if(g){if(p)return;p=o.Z.subscribe(window,"scroll",()=>{h>window.scrollY||h<=0?w||T(!0):w&&T(!1),h=window.scrollY},{debounce:10})}else x();return function(){x()}},[g,w]),n.createElement(n.Fragment,null,l&&n.createElement(m,{id:`${y}_global_header_fixed_spacer`}),n.createElement(u,{id:`${y}_global_header`,$isFixed:!!g||l,$forcePositionAbsolute:c,$visible:g?w:s,$shouldCollapseOffStage:f,"data-testid":"GlobalNav_container"}))};y.displayName="GlobalNav",y.propTypes={navScript:s().string,linkOutScript:s().string,menuLib:s().string,pageIncludesGlobalFooter:s().bool.isRequired,visible:s().bool,isFixed:s().bool,forcePositionAbsolute:s().bool,shouldCollapseOffStage:s().bool,shouldCollapseOnScroll:s().bool,brandOverride:s().oneOf(["nissan","infiniti"])},t.Z=y},78677:function(e,t,i){"use strict";i.d(t,{uT:function(){return P},TG:function(){return S},tI:function(){return O},ji:function(){return N},mD:function(){return C},rO:function(){return k},v0:function(){return D},Y6:function(){return A}});var n=i(2265),r=i(40718),s=i.n(r),a=i(89618),o=i(98019),l=i(64966);let c=[e=>e.replace(/\]\]\s*?\[\[/g,","),e=>e.replace(/\[\[/g,"<disclaimer>").replace(/\]\]/g,"</disclaimer>"),e=>e.replace(/\s<disclaimer>/g,"<disclaimer>")],f=({distanceOffset:e,tabIndex:t,analyticsData:i})=>({disclaimer:(r,s)=>{let a=[].concat(...r.children.map(e=>"string"==typeof e.data?e.data.split(","):null));return n.createElement(l.ZP,{key:s,disclaimerIds:a,distanceOffset:e,tabIndex:t,analyticsData:i})}});function g({children:e,distanceOffset:t,tabIndex:i,analyticsData:r}){return n.createElement(o.Z,{converters:f({distanceOffset:t,tabIndex:i,analyticsData:r}),preparsers:c},e)}g.displayName="DisclaimerParser",g.propTypes={children:s().oneOfType([s().node,s().string]),distanceOffset:s().number,tabIndex:s().number,analyticsData:s().object};var d=i(47460),m=i(25991);function u(){return(u=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var i=arguments[t];for(var n in i)Object.prototype.hasOwnProperty.call(i,n)&&(e[n]=i[n])}return e}).apply(this,arguments)}let p=["h1","h2","h3","h4","h5","h6","div","span","label","li","p","strong","td"],h=["primaryBlack","primaryWhite","red","blue1","grey1","secondaryLightGrey","secondaryDarkGrey","functionalDarkGrey","secondaryDarkMediumGrey","primaryBlue","almostBlack","secondaryDarkestGrey"],v=["none","capitalize","uppercase","lowercase","initial","inherit"],x={propTypes:{className:s().string,children:s().node,fontSize:s().number,fontWeight:s().oneOf(["light","normal","bold"]),lineHeight:s().number,noMargin:s().bool,marginBottom:s().number,tagName:s().oneOf(p),textAlign:s().oneOf(["inherit","left","center","right","justify"]),textColor:s().oneOf(h),textTransform:s().oneOf(v),disableDisclaimers:s().bool,disclaimerOffset:s().number,tabIndex:s().number,isTrimText:s().bool},defaultProps:{className:void 0,children:void 0,fontSize:16,fontWeight:"normal",lineHeight:void 0,noMargin:!1,marginBottom:0,tagName:"div",textAlign:"left",textColor:"primaryBlack",textTransform:"none",disableDisclaimers:!1,disclaimerOffset:void 0,tabIndex:void 0,isTrimText:!1}},b=a.ZP.div`
  /* Start CSS Resets */
  /* margin reset is 0, if noMargin is passed give 'margin: 0' high priority */
  ${({theme:e,$marginBottom:t,$noMargin:i})=>i?"&& { margin: 0; }":`margin: 0 0 ${e.utils.pxToRem(t)};`}
  padding: 0;
  border: 0;
  font-size: 100%;

  vertical-align: baseline;
  list-style: none;
  quotes: none;
  /* End CSS resets */

  /* Custom Styles */
  /* grab the fontSize and fontWeight directly so the props aren't rendered to the DOM as attributes */
  font-size: ${e=>e.theme.utils.pxToRem(e.$textSize)};

  /* FONT NOTE */
  /* Fonts and particularly FONT WEIGHTS are set based on the font family being used (bold, light, normal) */
  /* The actual specific font-weight property in the CSS  should ALWAYS be 400, this is to prevent confusion between */
  /* using a bold font with a light weight or other combination.  */
  font-weight: 400;
  /* font-weight should always bee 400, to bold or lighten use the light or bold font families from the theme */
  h1,
  h2,
  h3,
  h4,
  h5,
  p {
    font-weight: 400;
  }
  font-family: ${e=>e.theme.fonts[e.$weight]};
  /* prefer pxToRem (vs. unitless values) for line-height */
  line-height: ${e=>e.theme.utils.pxToRem(e.$lineHeight||e.$textSize)};
  text-align: ${e=>e.$textAlign||"left"};
  /* Attempt to apply color from theme, fall back to theme primary, fall back again to black */
  color: ${e=>e.theme.color[e.$textColor]||e.theme.color.primaryBlack};
  text-transform: ${e=>e.$textTransform||"none"};

  ${e=>e.$isTrimText&&` display: block;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      cursor: pointer;
    `}
`,y=(0,n.forwardRef)(({children:e,className:t,fontSize:i,fontWeight:r=x.defaultProps.fontWeight,lineHeight:s,noMargin:a=x.defaultProps.noMargin,marginBottom:l=x.defaultProps.marginBottom,tagName:c=x.defaultProps.tagName,textAlign:f=x.defaultProps.textAlign,textColor:d=x.defaultProps.textColor,textTransform:m=x.defaultProps.textTransform,disableDisclaimers:p=x.defaultProps.disableDisclaimers,disclaimerOffset:h,tabIndex:v,ariaHidden:y,isTrimText:w=x.isTrimText,analyticsData:T,...P},O)=>n.createElement(b,u({},P,{as:c,className:t,$textSize:i,$weight:r,$textAlign:f,$noMargin:a,$marginBottom:l,$textColor:d,$textTransform:m,$lineHeight:s,$isTrimText:w,ref:O}),p?n.createElement(o.Z,null," ",e):n.createElement(g,{distanceOffset:h,tabIndex:y?-1:v,analyticsData:T},e)));y.displayName="TypographyBase",y.propTypes=x.propTypes;let w={normal:14,primary:24},T={normal:62,primary:60},P=(0,n.forwardRef)(({fontSize:e,marginBottom:t=0,type:i="normal",fontWeight:r=x.defaultProps.fontWeight,lineHeight:s=24,noMargin:a=x.defaultProps.noMargin,tagName:o="p",textAlign:l=x.defaultProps.textAlign,textColor:c=x.defaultProps.textColor,textTransform:f=x.defaultProps.textTransform,disableDisclaimers:g=x.defaultProps.disableDisclaimers,disclaimerOffset:d=x.defaultProps.disclaimerOffset,isTrimText:m=!1,itemprop:p=x.defaultProps.itemprop,itemscope:h=x.defaultProps.itemscope,itemtype:v=x.defaultProps.itemtype,...b},P)=>n.createElement(y,u({fontSize:e||w[i],marginBottom:t>=0?t:T[i],tagName:o,ref:P,fontWeight:r,lineHeight:s,noMargin:a,textAlign:l,textColor:c,textTransform:f,disableDisclaimers:g,disclaimerOffset:d,isTrimText:m,itemProp:p,itemScope:h,itemType:v},b)));function O({fontSize:e=64,fontWeight:t="light",lineHeight:i=70,noMargin:r=x.defaultProps.noMargin,marginBottom:s=37.5,tagName:a="h1",textAlign:o=x.defaultProps.textAlign,textColor:l=x.defaultProps.textColor,textTransform:c=x.defaultProps.textTransform,disableDisclaimers:f=x.defaultProps.disableDisclaimers,disclaimerOffset:g=x.defaultProps.disclaimerOffset,isTrimText:d=!1,...m}){return n.createElement(y,u({fontSize:e,fontWeight:t,lineHeight:i,noMargin:r,marginBottom:s,tagName:a,textAlign:o,textColor:l,textTransform:c,disableDisclaimers:f,disclaimerOffset:g,isTrimText:d},m))}P.displayName="Body",P.propTypes={...x.propTypes,tagName:s().oneOf(p),type:s().oneOf(["normal","primary"])},O.propTypes={...x.propTypes,tagName:s().oneOf(p),textTransform:s().oneOf(v)};let $=(0,a.ZP)(y)`
  font-size: ${(0,m.Q1)(28)};
  line-height: ${(0,m.Q1)(30)};

  ${d.z2.large} {
    font-size: ${({fontSize:e})=>(0,m.Q1)(e)};
    line-height: ${({lineHeight:e})=>(0,m.Q1)(e)};
  }
`;function C({fontSize:e=32,fontWeight:t="light",lineHeight:i=40,noMargin:r=x.defaultProps.noMargin,marginBottom:s=45,tagName:a="h2",textAlign:o=x.defaultProps.textAlign,textColor:l=x.defaultProps.textColor,textTransform:c=x.defaultProps.textTransform,disableDisclaimers:f=x.defaultProps.disableDisclaimers,disclaimerOffset:g=x.defaultProps.disclaimerOffset,isTrimText:d=!1,...m}){return n.createElement($,u({fontSize:e,fontWeight:t,lineHeight:i,noMargin:r,marginBottom:s,tagName:a,textAlign:o,textColor:l,textTransform:c,disableDisclaimers:f,disclaimerOffset:g,isTrimText:d},m))}C.propTypes={...x.propTypes,tagName:s().oneOf(p)};let z=(0,a.ZP)(y)`
  font-size: ${(0,m.Q1)(20)};
  line-height: ${(0,m.Q1)(25)};

  ${d.z2.large} {
    font-size: ${({fontSize:e})=>(0,m.Q1)(e)};
    line-height: ${({lineHeight:e})=>(0,m.Q1)(e)};
  }
`;function k({fontSize:e=28,fontWeight:t="light",lineHeight:i=30,noMargin:r=x.defaultProps.noMargin,marginBottom:s=45,tagName:a="h3",textAlign:o=x.defaultProps.textAlign,textColor:l=x.defaultProps.textColor,textTransform:c=x.defaultProps.textTransform,disableDisclaimers:f=x.defaultProps.disableDisclaimers,disclaimerOffset:g=x.defaultProps.disclaimerOffset,isTrimText:d=!1,...m}){return n.createElement(z,u({fontSize:e,fontWeight:t,lineHeight:i,noMargin:r,marginBottom:s,tagName:a,textAlign:o,textColor:l,textTransform:c,disableDisclaimers:f,disclaimerOffset:g,isTrimText:d},m))}k.propTypes={...x.propTypes,tagName:s().oneOf(p),textColor:s().oneOf(h)};let E=(0,a.ZP)(y)`
  font-size: ${(0,m.Q1)(18)};
  line-height: ${(0,m.Q1)(20)};

  ${d.z2.large} {
    font-size: ${({fontSize:e})=>(0,m.Q1)(e)};
    line-height: ${({lineHeight:e})=>(0,m.Q1)(e)};
  }
`;function N({fontSize:e=20,fontWeight:t="normal",lineHeight:i=25,noMargin:r=x.defaultProps.noMargin,marginBottom:s=50,tagName:a="h4",textAlign:o=x.defaultProps.textAlign,textColor:l=x.defaultProps.textColor,textTransform:c=x.defaultProps.textTransform,disableDisclaimers:f=x.defaultProps.disableDisclaimers,disclaimerOffset:g=x.defaultProps.disclaimerOffset,isTrimText:d=!1,...m}){return n.createElement(E,u({fontSize:e,fontWeight:t,lineHeight:i,noMargin:r,marginBottom:s,tagName:a,textAlign:o,textColor:l,textTransform:c,disableDisclaimers:f,disclaimerOffset:g,isTrimText:d},m))}function S({fontSize:e=10,fontWeight:t="light",lineHeight:i=20,noMargin:r=x.defaultProps.noMargin,marginBottom:s=57.5,tagName:a="h5",textAlign:o=x.defaultProps.textAlign,textColor:l=x.defaultProps.textColor,textTransform:c=x.defaultProps.textTransform,disableDisclaimers:f=x.defaultProps.disableDisclaimers,disclaimerOffset:g=x.defaultProps.disclaimerOffset,isTrimText:d=!1,...m}){return n.createElement(y,u({fontSize:e,fontWeight:t,lineHeight:i,noMargin:r,marginBottom:s,tagName:a,textAlign:o,textColor:l,textTransform:c,disableDisclaimers:f,disclaimerOffset:g,isTrimText:d},m))}function D({fontSize:e=13,fontWeight:t=x.fontWeight,lineHeight:i=x.lineHeight,noMargin:r=x.noMargin,marginBottom:s=67,tagName:a="p",textAlign:o=x.textAlign,textColor:l=x.textColor,textTransform:c=x.textTransform,disableDisclaimers:f=x.disableDisclaimers,disclaimerOffset:g=x.disclaimerOffset,isTrimText:d=!1,...m}){return n.createElement(y,u({fontSize:e,fontWeight:t,lineHeight:i,noMargin:r,marginBottom:s,tagName:a,textAlign:o,textColor:l,textTransform:c,disableDisclaimers:f,disclaimerOffset:g,isTrimText:d},m))}N.propTypes={...x.propTypes,tagName:s().oneOf(p),textColor:s().oneOf(h)},S.propTypes={...x.propTypes,tagName:s().oneOf(p),textColor:s().oneOf(h)},D.propTypes={...x.propTypes,tagName:s().oneOf(p)};let Z=(0,a.ZP)(y)`
  color: #343434;
`;function A({fontSize:e=11,fontWeight:t="light",lineHeight:i=20,noMargin:r=x.noMargin,marginBottom:s=62,tagName:a="p",textAlign:o=x.textAlign,textColor:l=x.textColor,textTransform:c=x.textTransform,disableDisclaimers:f=x.disableDisclaimers,disclaimerOffset:g=x.disclaimerOffset,isTrimText:d=!1,...m}){return n.createElement(Z,u({fontSize:e,fontWeight:t,lineHeight:i,noMargin:r,marginBottom:s,tagName:a,textAlign:o,textColor:l,textTransform:c,disableDisclaimers:f,disclaimerOffset:g,isTrimText:d},m))}A.propTypes={...x.propTypes,tagName:s().oneOf(p)}},18667:function(e,t,i){"use strict";i.r(t),i.d(t,{default:function(){return S}});var n=i(57437),r=i(42586),s=i(99376),a=i(2265),o=i(75426),l=i(75560),c=i(469),f=i(36970),g=i(47460),d=i(66642),m=i(25991),u=i(65082),p=i(78677),h=i(89618);let v=h.ZP.div.withConfig({componentId:"sc-cdf4fe85-0"})(["height:inherit;display:flex;flex-direction:column;align-items:center;justify-content:center;"]),x=h.ZP.section.withConfig({componentId:"sc-cdf4fe85-1"})(["display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;gap:",";max-width:",";margin:auto;padding:0 ",";","{padding:",";}"],e=>{let{theme:t}=e;return t.isNissan?(0,m.Q1)(36):(0,m.Q1)(25)},e=>{let{theme:t}=e;return t.size.container.default},(0,m.Q1)(15),g.z2.medium,(0,m.Q1)(15)),b=(0,h.ZP)(p.tI).withConfig({componentId:"sc-cdf4fe85-2"})(["",""],e=>{let{theme:{isNissan:t}}=e;return(0,h.iv)(["font-size:",";line-height:",";text-align:center;font-weight:",";"],t?(0,m.Q1)(30):(0,m.Q1)(23),t?(0,m.Q1)(38):(0,m.Q1)(32),t?"normal":"light")}),y=(0,h.ZP)(d.Z).withConfig({componentId:"sc-cdf4fe85-3"})(["&&&{margin:0 0 ",";text-transform:none;width:100%;",";","{margin:0 0 ",";width:auto;}}"],(0,m.Q1)(10),e=>{let{theme:{isInfiniti:t}}=e;return t&&(0,h.iv)(["font:",";font-size:",";line-height:",";"],e=>{let{theme:t}=e;return t.fonts.normal},(0,m.Q1)(13),(0,m.Q1)(18))},g.z2.medium,(0,m.Q1)(14)),w=(0,h.ZP)(u.ZP).withConfig({componentId:"sc-cdf4fe85-4"})(["path{fill:",";}"],e=>{let{theme:{isNissan:t,color:i}}=e;return t?i.red:i.orange}),T=(0,h.ZP)(p.uT).withConfig({componentId:"sc-cdf4fe85-5"})(["margin-bottom:",";max-width:",";"],(0,m.Q1)(12),(0,m.Q1)(850)),P={"nissan-us-en":"https://www.nissanusa.com/dealer-locator","nissan-us-es":"https://es.nissanusa.com/dealer-locator","nissan-ca-en":"https://www.nissan.ca/dealer-locator.html","nissan-ca-fr":"https://fr.nissan.ca/dealer-locator.html","infiniti-us-en":"https://www.infinitiusa.com/locate-infiniti-retailer.html","infiniti-ca-en":"https://www.infiniti.ca/locate-infiniti-retailer.html","infiniti-ca-fr":"https://fr.infiniti.ca/locate-infiniti-retailer.html"};var O=function(e){let{error:t}=e,i=(0,r.useTranslations)("errorPage"),[g,d]=(0,a.useState)(!1),{isNissan:m,isInfiniti:u,brand:p}=(0,f.Z)(),{isCanada:h}=(0,o.Z)(),{locale:O}=(0,s.useParams)(),$=P["".concat(p,"-").concat(h?"ca":"us","-").concat(O)];return(0,a.useEffect)(()=>{let e=setInterval(()=>{window._satellite&&(d(!0),clearInterval(e))},100);return()=>clearInterval(e)},[]),(0,a.useEffect)(()=>{g&&(console.error("Error rendering page: ",t),(0,c.co)({action:c.o7,event:{errorInfo:t}}))},[t,g]),(0,n.jsx)(v,{children:(0,n.jsxs)(x,{children:[(0,n.jsx)(w,{size:40,icon:"error"}),(0,n.jsx)(b,{noMargin:!0,children:i("title")}),(0,n.jsx)(T,{textAlign:"center",textColor:m?"secondaryDarkestGrey":"grey8",fontSize:m?16:20,lineHeight:m?24:28,fontWeight:m?"light":void 0,children:(0,n.jsx)(b,{noMargin:!0,children:i((0,l.Z)("description"))})}),(0,n.jsx)(y,{onClick:()=>{var e,t;null===(t=window)||void 0===t||null===(e=t.location)||void 0===e||e.reload()},variant:m?"outline":"primary",caret:!0,iconName:"refresh-light",size:u?"medium":void 0,analyticsData:{action:c.JK,event:{interactionType:"error-cta",interactionValue:"refresh",locationInPage:"error page"}},children:i("buttonRefreshText")}),(0,n.jsx)(y,{"data-track-button":"contact your retailer","data-track-button-type":'error page"',"data-track-destination":$,url:$,variant:"outline",caret:!0,iconName:m?"arrow":null,size:u?"medium":void 0,children:i((0,l.Z)("buttonRetailerText"))})]})})},$=i(54672);let C=h.ZP.div.withConfig({componentId:"sc-1bd788c4-0"})(["background-color:",";position:absolute;top:0;left:0;z-index:6;width:inherit;height:inherit;"],e=>{let{theme:t}=e;return t.color.primaryWhite}),z=(0,$.f)("default"),k=(0,$.f)("medium"),E=(0,$.f)("large"),N=h.ZP.div.withConfig({componentId:"sc-1bd788c4-1"})(["position:relative;width:100vw;height:calc(100vh - ",");","{height:calc(100vh - ",");}","{height:calc(100vh - ",");}"],z,g.z2.medium,k,g.z2.large,E);function S(e){let{error:t}=e;return(0,n.jsx)(N,{children:(0,n.jsx)(C,{children:(0,n.jsx)(O,{error:t.digest})})})}},75426:function(e,t,i){"use strict";function n(){return{isCanada:!1,isUS:!0}}i.d(t,{Z:function(){return n}})},75560:function(e,t){"use strict";t.Z=e=>"".concat(e,".").concat("nissan")}},function(e){e.O(0,[4383,8350,2675,7648,375,1742,4966,2971,2117,1744],function(){return e(e.s=74400)}),_N_E=e.O()}]);